<?php
    $serverName="localhost";
    $username="root";
    $password="";
    $databasename="reactapp";
    $conn=mysqli_connect($serverName,$username,$password,$databasename);
     $recText=$_POST['itemName'];
     echo $recText;
     $query="insert into orders(itemName) values('$recText')";
     if(mysqli_query($conn,$query)){
        echo "Data has been inserted.";
   	 }
     else{
         echo "Error";
     }
?>