<?php
    include 'connect.php';
    include 'components.php';

    $sql = 'drop database reactapp';

    if($conn -> query($sql) == TRUE) {
        echo listItem("DataBase Deleted."); 
    }
    else {
        echo listItem("Database Deleted." . $conn->error);
    }

    $conn -> close();
?>