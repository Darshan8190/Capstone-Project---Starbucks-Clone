<?php
    include 'connect.php';
    include 'components.php';

    $sql = 'use reactapp';

    if($conn->query($sql) == TRUE) {
        echo "<br>Database Selected.";
    }
    else {
        echo "Databse Selection Error: " . $conn->error;
    }

    $sql = 'select * from orders limit 1';
    $orderId = null;

    $display = $conn->query($sql);
  
    if($display->num_rows > 0) {
        while($row = $display->fetch_assoc()) {
            echo "<form action='' method='POST' class='form-post'>";
            echo "<br>" . $row['id'] . ")&emsp;" . $row['itemName'] 
                . "&emsp;<input type= 'submit' name='accept' value='Accept'>" 
                . "&emsp;<input type= 'submit' id='inprogress' name='inprogress' value='Inprogress'>" 
                . "&emsp;<input type= 'submit' name='done' value='Done'>" 
                . "&emsp;<input type= 'submit' name='reject' value='Reject'>" . "<br>";
            echo "</form>";
            $orderId = $row['id'];
        }
    }
    
    if (isset($_POST['accept'])) {
        orderAccepted($orderId);
    } 

    if (isset($_POST['inprogress'])) {
        orderInprogress($orderId);
    } 

    if (isset($_POST['done'])) {
        orderDone($orderId);
    }

    if (isset($_POST['reject'])) {
        orderRejected($orderId);
    }
    
    function orderAccepted($orderId)
    {
        include 'connect.php';

        $sql="use reactapp";
        if($conn->query($sql)==TRUE){
            echo listItem("Database selected.");
        }
        else{
            echo listItem("Error:".$conn->error);
        }

        $sql = "update orders set accept=true where id='" . $orderId ."'";
        
        if($conn->query($sql) == TRUE) {
            echo listItem("Data Inserted.");
        }
        else {
            echo listItem("Insertion Error: " . $conn->error);
        }
    }
    
    function orderInprogress($orderId)
    {
        $inprogress = true;
        include 'connect.php';

        $sql="use reactapp";
        if($conn->query($sql)==TRUE){
            echo listItem("Database selected.");
        }
        else{
            echo listItem("Error:".$conn->error);
        }

        
        $sql = "update orders set inprogress=true where id='" . $orderId ."'";
        if($conn->query($sql) == TRUE) {
            echo listItem("Data Updated on orders table");
        }
        else {
            echo listItem("Insertion Error: " . $conn->error);
        }
    }

    function orderDone($orderId)
    {
       include 'connect.php';

        $sql="use reactapp";
        if($conn->query($sql)==TRUE){
            echo listItem("Database selected.");
        }
        else{
            echo listItem("Error:".$conn->error);
        }

        $sql = "delete from orders where id='" . $orderId . "'";
        
        if($conn->query($sql) == TRUE) {
            echo listItem("Data Updated on orders table");
        }
        else {
            echo listItem("Insertion Error: " . $conn->error);
        }
    }
    
    function orderRejected($orderId) {
        include 'connect.php';
        
        $sql="use reactapp";
        if($conn->query($sql)==TRUE){
            echo listItem("Database selected.");
        }
        else{
            echo listItem("Error:".$conn->error);
        }
        
        $sql = "delete from orders where id='" . $orderId . "'";
        
        if($conn->query($sql) == TRUE) {
            echo listItem("Data Updated on orders table");
        }
        else {
            echo listItem("Insertion Error: " . $conn->error);
        }
    }
?>