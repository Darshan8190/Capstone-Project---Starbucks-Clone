<?php
    function listItem($contents) {
        return "<div>" . $contents . "</div>";
    }
?>