<?php
    include 'connect.php';
    include 'components.php';

    $sql = 'create database reactapp';

    if($conn->query($sql) == TRUE) {
        echo listItem("Database Created."); 
    }
    else {
        echo listItem("DataBase Error: " . $conn->error);
    }

    $sql = 'use reactapp';

    if($conn->query($sql) == TRUE) {
        echo listItem("Database Selected."); 
    }
    else {
        echo listItem("Database Selection Error: " . $conn->error);
    }

    $sql = 'create table orders(
        id int not null auto_increment primary key,
        itemName varchar(50),
        accept BOOLEAN,
        inprogress BOOLEAN,
        done BOOLEAN,
        reject BOOLEAN
    )';

    if($conn->query($sql) == TRUE) {
        echo listItem("Table Created.");
    }
    else {
        echo listItem("Table Creation Error: " . $conn->error);
    }

    // $sql = 'insert into orders (itemName, accept, reject, inprogress, done)
    //         values("test", 0, 0, 0, 0);';
    
    // if($conn->query($sql) == TRUE) {
    //     echo listItem("Data Inserted.");
    // }
    // else {
    //     echo listItem("Insertion Error: " . $conn->error);
    // }

    $sql = 'create table lists(
        listid int not null auto_increment primary key,
        orderid int,
        itemName varchar(50),
        accept BOOLEAN,
        inprogress BOOLEAN,
        done BOOLEAN,
        reject BOOLEAN
        )';

    if($conn->query($sql) == TRUE) {
        echo listItem("Table Created.");
    }
    else {
        echo listItem("Table Creation Error: " . $conn->error);
    }

    $conn -> close();
?>