<?php
// header("Access-Control-Allow-Origin: *");

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");

    $serverName="localhost";
    $username="root";
    $password="";
    $databasename="reactapp";
    $conn=mysqli_connect($serverName,$username,$password,$databasename);

        $recText=$_POST['item'];
        // echo $recText;
        $query="insert into orders(itemName) values('$recText')";
        if(mysqli_query($conn,$query)){
            echo "Data has been inserted.";
   	 }
        else{
            echo "Error";
        }
    
?>