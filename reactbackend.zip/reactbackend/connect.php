<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $port = 3306;

    $conn = new mysqli($servername, $username, $password, null, $port);

    if($conn -> connect_error) {
        die("Connection failed: " . $conn -> connect_error);
    }

    echo "Connection Success!";
?>