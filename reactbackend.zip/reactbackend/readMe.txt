please insert this folder to htdocs within XAMPP folder.

Follow the following steps:
1. Open XAMPP or any other local enviroment application that you use
2. Start Apache and MySql Server.
3. Open localhost run - connect.php
4. Open localhost run - startup.php
5. Open localhost run - display.php

In order to start again or initialise the database
6. Open localhost run - reset.php
and follow steps 3 - 5

--- Please leave a feedback for the project
--- Cheers!!